#' SamsaRaLight
#'
#' This package is nice.
#'
#' Fill the package description !
#'
#' @name SamsaRaLight
#' @docType package
#' @noRd
NULL
