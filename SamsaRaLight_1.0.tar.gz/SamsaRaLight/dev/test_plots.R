library(dplyr)
library(ggplot2)
library(rgl)
library(plotly)
library(rayrender)
library(SamsaRaLight)

# 3D plots of stand geometry
plot_stand_geometry <- function(trees = NULL,
                                species_colors = NULL,
                                slope = 0, 
                                aspect = 0, 
                                north2x = 90) {
  
  
  if (any(!unique(trees$species) %in% names(species_colors))) {
    stop("Some species do not have specified colors")
  }
  
  # FUNCTIONS
  make_mesh_E <- function(x, y, z_ground, hbase, htop, radius,
                          n_theta = 30, n_phi = 15) {
    
    # Compute the ellispoid parameters
    a <- radius
    b <- radius
    
    # Vertical radius and center
    c <- (htop - hbase) / 2
    z0 <- (htop + hbase) / 2
    
    # Create theta and phi grid
    theta <- seq(0, pi, length.out = n_theta)
    phi <- seq(0, 2*pi, length.out = n_phi)
    theta_grid <- matrix(rep(theta, each=length(phi)), nrow=length(phi))
    phi_grid <- matrix(rep(phi, length(theta)), nrow=length(phi))
    
    # Ellipsoid coordinates
    x <- a * sin(theta_grid) * cos(phi_grid) + x
    y <- b * sin(theta_grid) * sin(phi_grid) + y
    z <- c * cos(theta_grid) + z0 + z_ground
    
    list(x = x, y = y, z = z) 
  }
  
  make_mesh_P <- function(x, y, z_ground, hbase, htop, radius,
                            n_theta = 30, n_phi = 15) {
    
    # Create theta and phi grid
    theta <- seq(0, pi/2, length.out = n_theta)  # only 0 to pi/2 for paraboloid (top to bottom)
    phi <- seq(0, 2*pi, length.out = n_phi)
    
    theta_grid <- matrix(rep(theta, each=length(phi)), nrow=length(phi))
    phi_grid <- matrix(rep(phi, length(theta)), nrow=length(phi))
    
    # Radial distance from center
    r <- radius * sin(theta_grid)  # sin(theta) to go from 0 (top) to radius (base)
    
    # Paraboloid height
    z <- htop - (htop - hbase) * (r^2 / radius^2)
    
    # Convert to Cartesian coordinates
    x <- r * cos(phi_grid) + x
    y <- r * sin(phi_grid) + y
    z <- z + z_ground
    
    list(x = x, y = y, z = z)
  }
  
  
  # Compute bottom azimut of the stand
  bottom_azimut <- get_bottom_azimut(aspect, north2x)
  
  # Compute tree z coordinate
  trees$z_ground <- -get_z(trees$x, trees$y,
                           deg2rad(slope), deg2rad(bottom_azimut))
  
  
  # Init the plot
  plt <- plot_ly()
    
  
  # ---- Add 3D crowns (ellipsoids) ----
  for(i in 1:nrow(trees)) {

    if (trees$crown_type[i] %in% c("E", "2E", "8E")) {
      crown_mesh <- make_mesh_E(
        x = trees$x[i],
        y = trees$y[i],
        z_ground = trees$z_ground[i],
        hbase = trees$hbase_m[i],
        htop  = trees$h_m[i],
        radius = mean(c(trees$rn_m[i], trees$rs_m[i], trees$re_m[i], trees$rw_m[i])),
        n_theta = 5, 
        n_phi = 5
      )
    } else if (trees$crown_type[i] %in% c("P", "4P")) {
      crown_mesh <- make_mesh_P(
        x = trees$x[i],
        y = trees$y[i],
        z_ground = trees$z_ground[i],
        hbase = trees$hbase_m[i],
        htop  = trees$h_m[i],
        radius = mean(c(trees$rn_m[i], trees$rs_m[i], trees$re_m[i], trees$rw_m[i])),
        n_theta = 5,
        n_phi = 5
      )
    } else {
      stop("Wrong crown type")
    }
    
    # Unique surfacecolor per tree
    surface_color_matrix <- matrix(1, nrow=nrow(crown_mesh$x), ncol=ncol(crown_mesh$x))
    
    # Add the surface
    plt <- plt %>%
      add_surface(
        x = crown_mesh$x,
        y = crown_mesh$y,
        z = crown_mesh$z,
        surfacecolor = surface_color_matrix,
        colorscale = list(c(0,1), c(species_colors[trees$species[i]], 
                                    species_colors[trees$species[i]])),
        cmin = 0, 
        cmax = 1,
        showscale = FALSE,
        opacity = 0.7
      )
  }
  
  
  # ---- Add trunks ----
  df_trunks <- do.call(rbind, lapply(1:nrow(trees), function(i) {
    data.frame(
      x = c(trees$x[i], trees$x[i]),
      y = c(trees$y[i], trees$y[i]),
      z = c(trees$z_ground[i], trees$z_ground[i] + trees$h_m[i]),
      id = trees$id_tree[i]
    )
  }))
  
  plt <- plt %>%
    add_trace(
      data = df_trunks,
      x = ~x, y = ~y, z = ~z,
      split = ~id,
      type = "scatter3d",
      mode = "lines",
      line = list(width = 3, color = "sienna"), 
      inherit = FALSE
    )
  
  
  # ---- Terrain ----
  df_geom_terrain <- data.frame(
    x = rep(c(0, size_x), each = 2),
    y = rep(c(0, size_y), time = 2)) %>%
    dplyr::mutate(z = -get_z(x, y,
                             deg2rad(slope),
                             deg2rad(bottom_azimut)))
  
  # ---- Center of the terrain ----
  size_x = max(trees$x) - min(trees$x)
  size_y = max(trees$y) - min(trees$y)
  
  cx <- (max(trees$x) - min(trees$x)) / 2
  cy <- (max(trees$y) - min(trees$y)) / 2
  
  
  # ---- Cardinal directions ----
  theta <- deg2rad(aspect - north2x)
  r <- min(size_x, size_y) / 2
  
  
  # East–West line
  df_geom_lineEW <- data.frame(
    x = cx + c( r * cos(theta + pi/2),
                r * cos(theta + 3*pi/2)),
    y = cy + c(-r * sin(theta + pi/2),
               -r * sin(theta + 3*pi/2)),
    z = 0,
    lab = c("E", "W")
  )
  
  # North–South line
  df_geom_lineNS <- data.frame(
    x = cx + c( r * cos(theta),
                r * cos(theta + pi)),
    y = cy + c(-r * sin(theta),
               -r * sin(theta + pi)),
    z = 0,
    lab = c("N", "S")
  )
  
  
  plt <- plt %>%
    
    # Plot the compass
    add_trace(data = df_geom_lineNS,
              x = ~x, y = ~y, z = ~z,
              type = "scatter3d", mode = "lines",
              line = list(width = 2, color = "red")) %>%
    add_text(data = df_geom_lineNS,
             x = ~x, y = ~y, z = ~z,
             text = ~lab, mode = "markers",
             textfont = list(size = 12, color = "black")) %>%
    
    add_trace(data = df_geom_lineEW,
              x = ~x, y = ~y, z = ~z,
              type = "scatter3d", mode = "lines",
              line = list(width = 2, color = "red")) %>%
    add_text(data = df_geom_lineEW,
             x = ~x, y = ~y, z = ~z,
             text = ~lab, mode = "markers",
             textfont = list(size = 12, color = "black")) %>%
    
    # Plot the terrain
    add_mesh(data = df_geom_terrain,
             x = ~x, y = ~y, z = ~z,
             intensity = ~z,
             opacity = 1,
             colorscale = 'Viridis') %>%
    
    hide_guides() %>% 
    layout(
      scene = list(
        # camera position and target
        camera = list(
          eye = list(x = -1.8, y = -1.8, z = 1.5),
          center = list(x = 0.15, y = 0.15, z = -0.1),
          up = list(x = 0, y = 0, z = 1)
        ),
        
        # automatically set axis ranges (to fit terrain)
        xaxis = list(autorange = TRUE),
        yaxis = list(autorange = TRUE),
        zaxis = list(autorange = TRUE)
      )
    )
  
  print(plt)
}


data <- SamsaRaLight::data_prenovel
species_colors <- c("Picea abies" = "#00D65C",
                    "Abies alba" = "#45AAF7",
                    "Fagus sylvatica" = "#F76045")

# data <- SamsaRaLight::data_cloture20
# species_colors <- c("Quercus sp." = "#CBD600",
#                     "Fagus sylvatica" = "#F76045")

# data <- SamsaRaLight::data_IRRES1
# species_colors <- c("Picea abies" = "#00D65C",
#                     "Abies alba" = "#45AAF7",
#                     "Fagus sylvatica" = "#F76045",
#                     "Pseudtsuga menziesii" = "#BF21AB",
#                     "Larix sp." = "#21BF9F")

# data <- SamsaRaLight::data_bechefa
# species_colors <- c("picea" = "#00D65C",
#                     "abies" = "#45AAF7",
#                     "fagus" = "#F76045",
#                     "pseudotsuga" = "#BF21AB")

plot_stand_geometry(trees = data$trees,
                    species_colors = species_colors,
                    slope = data$info[["slope"]], 
                    aspect = data$info[["aspect"]], 
                    north2x = data$info[["north_to_x_cw"]])




# 2D TOP DOWN view
plot_topdown <- function(sl_out) {
  
  data_trees <- dplyr::left_join(
    sl_out$input$trees,
    sl_out$output$trees,
    by = c("id_tree", "x", "y")
  )
  
  view_description <- c(
    "south" = "south view - W to E",
    "north" = "north view - E to W",
    "west" = "west view - N to S",
    "east" = "east view - S to N"
  )
  
  trees <- data_trees %>% 
    tidyr::crossing(view = names(view_description)) %>% 
    dplyr::mutate(
      
      view_label = view_description[view],
      
      # Height of the maximum radius
      hmax_m = case_when(
        crown_type == "E" ~ (h_m + hbase_m) / 2, 
        crown_type == "P" ~ hbase_m,
        crown_type == "8E" ~ hmax_m
      ),
      
      # define tree position given the view
      pos = case_when(
        view == "south" ~ x,
        view == "north" ~ -x,
        view == "west" ~ -y,
        view == "east" ~ y
      ),
      
      # define left/right radius given the view
      r_left_m = case_when(
        view == "south" ~ rw_m,
        view == "north" ~ re_m,
        view == "west" ~ rn_m,
        view == "east" ~ rs_m
      ),
      r_right_m = case_when(
        view == "south" ~ re_m,
        view == "north" ~ rw_m,
        view == "west" ~ rs_m,
        view == "east" ~ rn_m
      )
    )
  
  # 2D top/down
  ggplot(trees) +
    # trunks
    geom_segment(aes(x = pos, xend = pos, 
                     y = z, yend = z + hmax_m), 
                 linewidth = 0.1) +
    
    # --- Ellipsoids ---
    geom_curve(
      data = subset(trees, crown_type %in% c("E", "2E", "8E")),
      aes(x = pos - r_left_m, xend = pos, 
          y = z + hmax_m, yend = z + h_m, 
          color = species),
      curvature = -0.4
    ) +
    geom_curve(
      data = subset(trees, crown_type %in% c("E", "2E", "8E")),
      aes(x = pos + r_right_m, xend = pos, 
          y = z + hmax_m, yend = z + h_m, 
          color = species),
      curvature = 0.4
    ) +
    
    # --- Paraboloids ---
    geom_curve(
      data = subset(trees, crown_type %in% c("P", "4P")),
      aes(x = pos - r_left_m, xend = pos, 
          y = z + hmax_m, yend = z + h_m, 
          color = species),
      curvature = -0.2
    ) +
    geom_curve(
      data = subset(trees, crown_type %in% c("P", "4P")),
      aes(x = pos + r_right_m, xend = pos, 
          y = z + hmax_m, yend = z + h_m, 
          color = species),
      curvature = 0.2
    ) +
    
    labs(x = "Position", y = "Height (m)") +
    coord_equal() +
    theme_bw() +
    facet_wrap(~view_label, ncol = 1)
  
}


# TEST

sl_stand <- SamsaRaLight::create_rect_stand(
  trees = data$trees,
  cell_size = 10,
  core_polygon_df = data$core_polygon,
  use_rect_zone = ifelse(is.null(data$core_polygon), TRUE, FALSE),
  fill_around = TRUE
)

sl_out <- SamsaRaLight::sl_run(
  trees = sl_stand$trees,
  monthly_rad = data$radiations,
  slope = data$info[["slope"]],
  north_to_x_cw = data$info[["north_to_x_cw"]],
  aspect = data$info[["aspect"]],
  cell_size = sl_stand$info$cell_size,
  n_cells_x = sl_stand$info$n_cells_x,
  n_cells_y = sl_stand$info$n_cells_y
)

plot_topdown(sl_out)
plot_3D_stand(sl_out)



# 3D interactive
# open3d()
# for (i in 1:nrow(trees)) {
#   print(paste0(i, "/", nrow(trees)))
#   t <- trees[i, ]
#   # trunk
#   shade3d(cylinder3d(
#     center = matrix(c(t$x, t$y, 0, t$x, t$y, t$hbase_m), ncol = 3, byrow = TRUE),
#     radius = t$dbh_cm / 100 / 2,
#     sides = 20
#   ), color = "sienna4")
#   
#   # crown (ellipsoid)
#   # if (t$shape == "ellipsoid") {
#   shade3d(ellipse3d(
#     diag(c(t$rn_m, t$rn_m, t$h_m - t$hbase_m)),
#     centre = c(t$x, t$y, t$hbase_m)
#   ), color = "forestgreen", alpha = 0.5)
#   # }
# }
# axes3d()

# Rayrender
# scene <- generate_ground(material = diffuse(checkercolor = "grey20"))
# for (i in 1:nrow(trees)) {
#   print(paste0(i, "/", nrow(trees)))
#   t <- trees[i, ]
#   scene <- add_object(scene,
#                       cylinder(x = t$x, y = t$y, z = t$hbase_m / 2,
#                                radius = t$dbh_m / 100 / 2, length = t$hbase_m,
#                                material = diffuse(color = "sienna4"))
#   )
#   
#   scene <- add_object(scene,
#                       ellipsoid(x = t$x, y = t$y, z = (t$hbase_m + t$h_m) / 2,
#                                 a = t$rn_m/ 2, b = t$rn_m/ 2, c = (t$h_m - t$hbase_m) / 2,
#                                 material = diffuse(color = "forestgreen"))
#   )
# }
# render_scene(scene[1:2,], lookfrom = c(0, -50, 30), lookat = c(0, 0, 15), fov = 40)
