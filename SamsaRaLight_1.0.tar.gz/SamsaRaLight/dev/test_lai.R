library(dplyr)
library(SamsaRaLight)

pi <- 3.1415

# Regular crowns
stand_area_prenovel <- SamsaRaLight::data_prenovel$info[["size_x"]] * SamsaRaLight::data_prenovel$info[["size_y"]]

lai_prenovel <- SamsaRaLight::data_prenovel$trees %>% 
  dplyr::mutate(
    volume_m3 = case_when(
      crown_type == "P" ~ 0.5 * pi * rn_m^2 * (h_m - hbase_m),
      crown_type == "E" ~ (2/3) * pi * rn_m^2 * (h_m - hbase_m)
    ),
    leaf_area_m2 = crown_lad * volume_m3
  ) %>% 
  dplyr::summarise(
    lai = sum(leaf_area_m2) / stand_area_prenovel
  ) %>% 
  dplyr::pull(lai)

lai_prenovel


# Irregular crowns with core polygon

## Get the area of the inventory zone
stand_bechefa <- create_rect_stand(
  trees = SamsaRaLight::data_bechefa$trees, 
  cell_size = 10, 
  core_polygon_df = SamsaRaLight::data_bechefa$core_polygon
)
stand_area_bechefa <- stand_bechefa$info$core_area_ha * 10000

## Compute LAI for each fourth of ellipsoid
lai_bechefa <- SamsaRaLight::data_bechefa$trees %>% 
  dplyr::mutate(
    
    # Volumes of the upper fourths
    c_top = h_m - hmax_m,
    v_upper_n = (4/3) * pi * rn_m^2 * c_top / 8,
    v_upper_s = (4/3) * pi * rs_m^2 * c_top / 8,
    v_upper_w = (4/3) * pi * rw_m^2 * c_top / 8,
    v_upper_e = (4/3) * pi * re_m^2 * c_top / 8,
    v_upper = v_upper_n + v_upper_s + v_upper_w + v_upper_e,
    
    # Volumes of the lower fourths
    c_bot = hmax_m - hbase_m,
    v_lower_n = (4/3) * pi * rn_m^2 * c_bot / 8,
    v_lower_s = (4/3) * pi * rs_m^2 * c_bot / 8,
    v_lower_w = (4/3) * pi * rw_m^2 * c_bot / 8,
    v_lower_e = (4/3) * pi * re_m^2 * c_bot / 8,
    v_lower = v_lower_n + v_lower_s + v_lower_w + v_lower_e,
    
    # Volume of the assymetric crown
    volume_m3 = v_upper + v_lower,
    
    # Leaf area of the crown
    leaf_area_m2 = crown_lad * volume_m3
  ) %>% 
  dplyr::summarise(
    lai = sum(leaf_area_m2) / stand_area_bechefa
  ) %>% 
  dplyr::pull(lai)

lai_bechefa
